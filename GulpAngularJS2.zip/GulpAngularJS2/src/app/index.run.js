(function() {
  'use strict';

  angular
    .module('gulpAngularJs2')
    .run(runBlock);

  /** @ngInject */
  function runBlock($log) {

    $log.debug('runBlock end');
  }

})();
