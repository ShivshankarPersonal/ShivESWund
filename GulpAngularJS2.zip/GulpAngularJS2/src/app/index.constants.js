/* global malarkey:false, moment:false */
(function() {
  'use strict';

  angular
    .module('gulpAngularJs2')
    .constant('malarkey', malarkey)
    .constant('moment', moment);

})();
